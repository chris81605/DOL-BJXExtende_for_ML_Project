WINMERGE

WinMerge h� un attrezzu di paragone � di fusione � fonte aperta per Windows.
WinMerge p� paragun� cartulari � schedarii � affiss� e sfarenze in un furmatu
di testu visuale ch� h� capicitoghju � faciule � manighj�. WinMerge p� esse
impiegatu, sia cum�� un attrezzu esternu di paragone o di fusione, sia cum��
un�appiecazione autonoma.

WinMerge cuntene tante funzioni per rende pi� faciule u paragone, a
sincrunizazione � a fusione. Parechji linguaghji di prugrammazione � altri
furmati di schedariu anu a so sintassa sopralineata.

L�ultime versione � infurmazione di WinMerge s� dispunibule � l�indirizzu�:
	https://winmerge.org/

Lanciu rapidu
=============
Per ampar� cumu f� l�operazioni basichi dopu � l�installazione di WinMerge,
cliccu nant�� Aiutu > Aiutu WinMerge � navigate � u paragrafu di u lanciu
rapidu. Osinn�, impiegate a versione web � l�indirizzu�:
	https://manual.winmerge.org/Quick_start.html

Aiutu WInMerge
============== 
L�aiutu di WinMerge h� installatu di lucale cum�� un schedariu d�aiutu HTML
Microsoft, WinMerge.chm, durante l�installazione de WinMerge. Per apre
l�aiutu, cliccu nant�� Aiutu > Aiutu WinMerge o appughjate nant�� u tastu F1
in a finestra di WinMerge. Nant�� a linea di cumanda, lanciate u schedariu
d�esecuzione WinMerge c� u cumutatore d�aiutu /?.

Pudete din� sfugli� a versione HTML di l�aiutu di WinMerge � l�indirizzu�:
	https://manual.winmerge.org/

Assistenza WinMerge
===================
Dumande o sugestioni apprupositu di WinMerge�? Un bellu locu per principi�
h� u foru di chjachjerata di a cumunit� WinMerge ch� si trova � l�indirizzu
https://github.com/WinMerge/winmerge/discussions. Di manera regulare,
i sviluppatori leghjenu � rispondenu � e dumande nant�� stu foru.
Impiegate i fori di chjachjarata generale per i penseri nant�� WinMerge,
cum�� e dumande apprupositu di u so adopru. Impiegate u foru di
i sviluppatori per i penseri nant�� u sviluppu di WinMerge.

Riferimentu di prublemi � dumande di funzioni
=============================================
S�� un penseru �n h� micca scioltu via u foru di chjachjerata di WinMerge,
verificate u ghjestiunariu di penseri di u prughjettu � l�indirizzu
https://github.com/WinMerge/winmerge/issues induve si p� cunsult�
l�articuli dighj� creati o mand� e vostre dumande.

S�� vo mandate un raportu di prublema, ci vole � indic� u numeru di
versione di WinMerge in u vostru raportu. Pudete ingener� un ghjurnale
di cunfigurazione grazia � l�azzione Aiutu > Cunfigurazione. Ci vole �
aghjunghje stu ghjurnale � u vostru raportu di prublema perch� ci h�
parechje infurmazioni ghjuvevule per i sviluppatori.


- I sviluppatori di WinMerge
