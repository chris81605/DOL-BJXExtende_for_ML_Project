
/**
 * ?vulva - Returns one of many varieties of terms each referring to
 * 			 Female genitals.
 */
Template.add("vulva", () => either("外阴", "私处", "下身", "小穴"));

Template.add("Vulva", () => either("外阴", "私处", "下身", "小穴"));






