
const ZIndices = {
	bg: 0,

	over_head_back: 0,
	head_back: 1,
	basehead: 5,
	tail: 9,
	backhair: 10,
	back_lower: 15,
	base: 20,
	facebase: 21,
	tanBody: 22,
	hirsute: 25,
	eyes: 30,
	sclera: 31,
	iris: 32,
	irisacc: 33,
	eyelids: 34,
	lashes: 35,
	mouth: 40,
	armsidle: 30,
	handsidle: 31.5,
	under_upper_arms: 32,
	bellyBase: 33,
	breasts: 35,
	breastsparasite: 36,
	tanbreasts: 30,
	blush: 50,
	freckles: 51,
	mascara_running: 51.5,
	skin: 52,
	toast: 53,
	tears: 55,
	hair: 60,
	penis_chastity: 64,
	legs: 66.6, // above underParasite but below under_lower
	pbhair: 64,
	penisunderclothes: 64.3,
	pbhairballsunderclothes: 64.6,
	genitals: 65,
	penis: 104, // when exposed
	pbhairballs: 104.3, // when exposed
	parasite: 104.6, // when exposed
	underParasite: 66,
	under_lower: 67,
	under_lower_top: 68,
	under_upper: 70,
	under_upper_top: 72,
	under_upper_top_high: 73,
	under_upper_top_acc: 74,
	under_lower_high: 75,
	under_lower_top_high: 77,
	under_lower_top_high_acc: 78,
	under: 75,
	feet: 85,
	lower: 90,
	lower_top: 92,
	upper_arms: 94,
	lower_belly: 94.5,
	upper: 95,
	upper_tucked: 89,
	upper_arms_tucked: 88.5,
	upper_top: 97,
	bellyClothes: 98,
	bellyClothesShadow: 99,

	collar: 103,
	neck: 103,

	arms_cover: 105,
	under_upper_arms_cover: 109,
	hands: 110,
	upper_arms_cover: 112,
	lower_high: 115,
	lower_top_high: 117,

	hairforwards: 132,
	fronthair: 133,
	ears: 132.5,
	semencough: 135,
	backbrow: 58,
	brow: 138,
	horns: 140,
	face: 145,
	head: 150,
	over_head: 152,

	tailPenisCover: 165,
	tailPenisCoverOverlay: 166,

	over_lower: 170,
	over_upper: 171,
	over_upper_arms: 170,
	over_upper_arms_cover: 174,
};
window.ZIndices = ZIndices;






