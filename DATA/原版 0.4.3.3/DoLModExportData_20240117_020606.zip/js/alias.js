
Object.defineProperties(window, {
	/* Constants property. */
	C: {
		get() {
			return Constants;
		},
	},
	/* Compute property. */
	CU: {
		value: {},
	},
});






