DoLHouse.add({ //IT IS VERY IMPORTANT THAT THE FIRST LINE IN YOUR FILE IS A COPY-PASTE OF THIS LINE

    player: {
        frames: 4,
        selected_variant: "doggy",        
        variants: {            
            doggy: {
                import: {
                    filepath: "doggy/doggy.js",
                    variable: "doggy"
                }
            },
            missionary: {
                /*import: {
                    filepath: "missionary/missionary.js",
                    variable: "missionary_bottom"
                }*/
            }
        }
    }

}); //IT IS VERY IMPORTANT THAT THE LAST LINE IN YOUR FILE IS A COPY-PASTE OF THIS LINE





