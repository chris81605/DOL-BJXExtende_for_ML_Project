
/* ?semen */
Template.add(["semen", "sperm", "cum"], () => either("semen", "sperm", "cum"));





